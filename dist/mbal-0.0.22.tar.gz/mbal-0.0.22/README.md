# mbal

Material Balance Calculations

Test the commitments (python -m unittest discover -v)