import numpy

from scipy.optimize import minimize

from ._model import Model

from ._cruncher import Cruncher

class Tank():

	def __init__(self,**kwargs):

		self._initial = Model(**kwargs)

	@property
	def initial(self):
		return self._initial

	def __call__(self,**kwargs):
		"""Defines the current state of the tank by altering only the new properties."""

		self._current = self._initial()

		self._current._M = None

		self._current(inplace=True,**kwargs)

		return self

	@property
	def current(self):
		return self._current
	
	def minimize(self,alter_initial=False,optimizer:dict=None,**kwargs):
		"""
		Minimizes the difference between total drive index and 1 for the current model.

		alter_initial 	: the model index whose parameters will be altered.

		Returns the OptimizeResult where the x includes the optimized values of kwargs keys.
		"""

		initial_model = self.initial()

		current_model = self.current()

		keys,values = list(kwargs.keys()),list(kwargs.values())

		def objective(values,keys):

			locdict = dict(zip(keys,values))

			if alter_initial:
				initial_model = initial_model(**locdict)
				initial_model.update_fluid_volumes()
			else:
				current_model = current_model(**locdict)
				current_model.update_fluid_volumes()

			ddi = self.drive_index(initial_model,current_model,which="DDI",safe=True)
			sdi = self.drive_index(initial_model,current_model,which="SDI",safe=True)
			wdi = self.drive_index(initial_model,current_model,which="WDI",safe=True)
			edi = self.drive_index(initial_model,current_model,which="EDI",safe=True)

			return (ddi+sdi+wdi+edi-1)**2

		return minimize(objective,values,args=(keys,),**optimizer) # minimize(tank,0,N=1000_000)

	def drive_index(self,which:str="DDI",safe:bool=False):
		"""Returns the drive index for the mbal model with respect to initial state."""
		return Cruncher.drive_index(self.initial,self.current,which,safe)
