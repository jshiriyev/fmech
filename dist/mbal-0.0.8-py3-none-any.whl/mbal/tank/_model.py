from ._reservoir import Reservoir

from ._phase import Phase

from ._dynamic import Operation

class MBTank():

	def __init__(self,reservoir:dict=None,phase:dict=None,operation:dict=None):
		"""Initialization of Material Balance Tank Model."""

		self._reservoir = Reservoir(**(reservoir or {}))

		self._phase = Phase(**(phase or {}))

		self._operation = Operation(**(operation or {}))

	def __call__(self,**kwargs):
		"""Updating altered Material Balance Tank Model properties."""

		for key,value in kwargs.items():

			if key in self.reservoir.__dict__:
				setattr(self.reservoir,key,value)
			elif key in self.phase.__dict__:
				setattr(self.phase,key,value)
			elif key in self.operation.__dict__:
				setattr(self.operation,key,value)
			else:
				print(f"Warning: Key '{key}' not found in any sub-class properties.")

		return self

	@property
	def reservoir(self):
		return self._reservoir

	@property
	def phase(self):
		return self._phase

	@property
	def operation(self):
		return self._operation

	@property
	def gcg2oil(self):
		"""Ratio of gas-cap-gas reservoir volume to reservoir oil volume, bbl/bbl"""
		return (self.reservoir.G*self.phase.Bg)/(self.reservoir.N*self.phase.Bo)

	@property
	def porevolume(self):
		"""Pore volume, bbl"""
		return (self.reservoir.N*self.phase.Bo)*(1+self.gas2oil)/(1-self.reservoir.Sw)