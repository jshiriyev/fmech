from . import tank

from .tank._model import MBTank as Tank

from ._solver import Solver